package pe.edu.unmsm.fisi.upg.ads.dirtycode.domain;

public interface IRepository {
	int saveSpeaker(Speaker speaker);
}