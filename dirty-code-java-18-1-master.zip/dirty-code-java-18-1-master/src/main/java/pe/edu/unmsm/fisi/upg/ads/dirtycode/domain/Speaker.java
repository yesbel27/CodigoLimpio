package pe.edu.unmsm.fisi.upg.ads.dirtycode.domain;

import java.util.Arrays;
import java.util.List;

import pe.edu.unmsm.fisi.upg.ads.dirtycode.exceptions.NoSessionsApprovedException;
import pe.edu.unmsm.fisi.upg.ads.dirtycode.exceptions.SpeakerDoesntMeetRequirementsException;

public class Speaker {
	private String firstName;
	private String lastName;
	private String email;
	private int exp;
	private boolean hasBlog;
	private String blogURL;
	private WebBrowser browser;
	private List<String> certifications;
	private String employer;
	private int registrationFee;
	private List<Session> sessions;

	public Integer register(IRepository repository) throws Exception {
		Integer speakerId = null;
		boolean good = false;
		boolean appr = false;
                String constvar1 = "Cobol";
                String constvar2 = "Punch Cards";
                String constvar3 = "Commodore";
                String constvar4 = "VBScript";
                String constvar5 = "aol.com";
                String constvar6 = "hotmail.com";
                String constvar7 = "prodigy.com";
                String constvar8 = "compuserve.com";
                String constvar9 = "Pluralsight";
                String constvar10 = "Microsoft";
                String constvar11 = "Google";
                String constvar12 = "Fog Creek Software";
                String constvar13 = "37Signals";
                String constvar14 = "Telerik";
                String constvar15 = "@";
                String constvar16 = "Can't register speaker with no sessions to present.";
                String constvar17 = "No sessions approved.";
                String constvar18 = "Speaker doesn't meet our abitrary and capricious standards.";
                String constvar19 = "First Name is required";
                
                int constent0 = 0;
                int constent1 = 1;
                int constent2 = 2;
                int constent3 = 3;
                int constent4 = 4;
                int constent5 = 5;
                int constent6 = 6;
                int constent9 = 9;
                int constent10 = 10;
                int constent500 = 500;
                int constent250 = 250;
                int constent100 = 100;
                int constent50 = 50;
	
		String[] ot = new String[] { constvar1, constvar2, constvar3, constvar4 };
		
		List<String> domains = Arrays.asList(constvar5, constvar6, constvar7, constvar8);
		
		if (!(this.firstName.isEmpty() && this.lastName.isEmpty() && this.email.isEmpty())) {
					List<String> emps = Arrays.asList(constvar9, constvar10,constvar11, constvar12, constvar13, constvar14);
					
					good = ((this.exp > constent10 || this.hasBlog || this.certifications.size() > constent3 || emps.contains(this.employer)));
					
					if (!good) {
						String[] splitted = this.email.split(constvar15);
						String emailDomain = splitted[splitted.length - constent1];

						if (!domains.contains(emailDomain) && (!(browser.getName() == WebBrowser.BrowserName.InternetExplorer && browser.getMajorVersion() < constent9)))
						{
							good = true;
						}
					}
					
					if (good) {
						if (!this.sessions.isEmpty()) {
							for (Session session : sessions) {
								for (String tech : ot) {
									if (session.getTitle().contains(tech) || session.getDescription().contains(tech)) {
										session.setApproved(false);
										break;
									} else {
										session.setApproved(true);
										appr = true;
									}
								}
								
							}
						} else {
							throw new IllegalArgumentException(constvar16);
						}
						
						if (appr) {
							if (this.exp <= constent1) {
								this.registrationFee = constent500;
							}
							else if (exp >= constent2 && exp <= constent3) {
								this.registrationFee = constent250;
							}
							else if (exp >= constent4 && exp <= constent5) {
								this.registrationFee = constent100;
							}
							else if (exp >= constent6 && exp <= constent9) {
								this.registrationFee = constent50;
							}
							else {
								this.registrationFee = constent0;
							}
							
							try {
								speakerId = repository.saveSpeaker(this);
							} catch (Exception e) {
								//in case the db call fails 
							}
						} else {
							throw new NoSessionsApprovedException(constvar17);
						}
					} else {
						throw new SpeakerDoesntMeetRequirementsException(constvar18);
					}				
			 			
		} else {
			throw new IllegalArgumentException(constvar19);
		}
			
		return speakerId;
	}

	public List<Session> getSessions() {
		return sessions;
	}

	public void setSessions(List<Session> sessions) {
		this.sessions = sessions;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getExp() {
		return exp;
	}

	public void setExp(int exp) {
		this.exp = exp;
	}

	public boolean isHasBlog() {
		return hasBlog;
	}

	public void setHasBlog(boolean hasBlog) {
		this.hasBlog = hasBlog;
	}

	public String getBlogURL() {
		return blogURL;
	}

	public void setBlogURL(String blogURL) {
		this.blogURL = blogURL;
	}

	public WebBrowser getBrowser() {
		return browser;
	}

	public void setBrowser(WebBrowser browser) {
		this.browser = browser;
	}

	public List<String> getCertifications() {
		return certifications;
	}

	public void setCertifications(List<String> certifications) {
		this.certifications = certifications;
	}

	public String getEmployer() {
		return employer;
	}

	public void setEmployer(String employer) {
		this.employer = employer;
	}

	public int getRegistrationFee() {
		return registrationFee;
	}

	public void setRegistrationFee(int registrationFee) {
		this.registrationFee = registrationFee;
	}
}